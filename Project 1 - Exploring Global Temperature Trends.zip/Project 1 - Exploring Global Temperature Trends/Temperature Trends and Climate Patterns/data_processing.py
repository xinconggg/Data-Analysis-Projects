import pandas as pd


def clean_data(data):
    # Display First 5 Rows
    ## print(data.head())
    data['last_updated'] = pd.to_datetime(data['last_updated'], dayfirst=True)
    data['last_updated'] = data['last_updated'].dt.date
    # Summary Statistics
    ## print(data.describe())
    # Check Data Type and Missing Values
    ## print(data.info())

    # Check for NULL Values
    ## print(data.isnull().sum())
    # Remove NULL Values
    data = data.dropna()
    # Check for NULL values again
    ## print(data.isnull().sum())

    # Check for Misspellings or Inconsistencies
    ## print(data['country'].unique())
    ## print(data['location_name'].unique())
    return data


def create_subsets(data):
    # Create a subset for Global Locations
    global_subset = data[data['country'] != 'Singapore'].reset_index()
    # Create a subset for Singapore
    singapore_subset = data[data['country'] == 'Singapore'].reset_index()
    return global_subset, singapore_subset


def save_cleaned_datasets(global_subset, singapore_subset):
    global_subset.to_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\GlobalSubset_Cleaned.csv", index=False)
    singapore_subset.to_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\SingaporeSubset_Cleaned.csv", index=False)
