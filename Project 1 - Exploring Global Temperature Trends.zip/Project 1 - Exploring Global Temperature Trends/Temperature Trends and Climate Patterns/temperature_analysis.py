import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from time_series_analysis import preprocess_time_series, apply_adf_test, plot_acf_pacf, fit_arima_model, forecast_future_temperatures, plot_forecast


def combine_global_subset(global_subset):
    # Remove country and location_name
    global_subset = global_subset.drop(['country', 'location_name'], axis=1)
    # Group by Date then Calculate Mean for each Variable
    mean_global_subset = global_subset.groupby('last_updated').mean().reset_index()
    # Save the Mean Dataset to a new CSV file
    mean_global_subset.to_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\meanGlobalSubset.csv", index=False)
    return mean_global_subset


def plot_correlation_heatmap(mean_global_subset, singapore_subset):
    # Combine both Global and Singapore data
    combined_data = pd.concat([mean_global_subset, singapore_subset], ignore_index=True)
    correlation_matrix_combined = combined_data[['temperature_celsius', 'wind_kph', 'pressure_mb', 'humidity', 'precip_mm']].corr()
    # Create a correlation heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(correlation_matrix_combined, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5, square=True)
    plt.title('Correlation Heatmap: Combined Global and Singapore Data')
    plt.show()


def plot_temperature_trends(mean_global_subset, singapore_subset):
    plt.figure(figsize=(14, 6))
    # Temperature trend for Global
    sns.lineplot(x='last_updated', y='temperature_celsius', data=mean_global_subset, label='Global')
    # Temperature trend for Singapore
    sns.lineplot(x='last_updated', y='temperature_celsius', data=singapore_subset, label='Singapore')
    # Set plot title and labels
    plt.title('Temperature Trends Over Time: Global vs. Singapore')
    plt.xlabel('Date and Time')
    plt.ylabel('Temperature (°C)')
    # Set legend and display Line Plot
    plt.legend()
    plt.show()


def time_series_analysis(global_subset, singapore_subset):
    # Your time series analysis code here
    mean_global_subset = combine_global_subset(global_subset)
    global_time_series, singapore_time_series = preprocess_time_series(mean_global_subset, singapore_subset)
    global_result, singapore_result = fit_arima_model(global_time_series, singapore_time_series)
    global_forecast_mean, singapore_forecast_mean, future_years = forecast_future_temperatures(global_result, singapore_result)
    apply_adf_test(global_time_series, singapore_time_series)
    plot_acf_pacf(global_time_series, singapore_time_series)
    plot_forecast(future_years, global_forecast_mean, singapore_forecast_mean)






