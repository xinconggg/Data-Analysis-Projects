import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf


def preprocess_time_series(mean_global_subset, singapore_subset):
    # Convert to datetime format
    mean_global_subset['last_updated'] = pd.to_datetime(mean_global_subset['last_updated'], dayfirst=True)
    singapore_subset['last_updated'] = pd.to_datetime(singapore_subset['last_updated'], dayfirst=True)

    # Extract Year and Temperature for Time-Series
    global_time_series = mean_global_subset[['last_updated', 'temperature_celsius']]
    singapore_time_series = singapore_subset[['last_updated', 'temperature_celsius']]

    # Set last_updated column as Index
    global_time_series = global_time_series.set_index('last_updated')
    singapore_time_series = singapore_time_series.set_index('last_updated')

    # Create a new time index with daily frequency
    global_time_index = pd.date_range(start=global_time_series.index.min(), end=global_time_series.index.max(), freq='D')
    singapore_time_index = pd.date_range(start=singapore_time_series.index.min(), end=singapore_time_series.index.max(), freq='D')

    # Reindex the time series with the new time index
    global_time_series = global_time_series.reindex(global_time_index)
    singapore_time_series = singapore_time_series.reindex(singapore_time_index)
    return global_time_series, singapore_time_series


def apply_adf_test(global_time_series, singapore_time_series):
    # result = adfuller(global_time_series)
    # # Extract the test statistic and p-value
    # test_statistic = result[0]
    # p_value = result[1]
    # print(f'Test Statistic: {test_statistic}')
    # print(f'P-value: {p_value}')
    # # Check for stationarity
    # if p_value <= 0.05:
    #     print('The time series is likely stationary.')
    # else:
    #     print('The time series is likely non-stationary.')
    # # Apply Differencing
    # differenced_data = global_time_series.diff().dropna()
    # # Perform ADF test on the differenced data
    # result_diff = adfuller(differenced_data)
    # test_statistic_diff = result_diff[0]
    # p_value_diff = result_diff[1]
    # print(f'Test Statistic (after differencing): {test_statistic_diff}')
    # print(f'P-value (after differencing): {p_value_diff}')
    # # Check for stationarity after differencing
    # if p_value_diff <= 0.05:
    #     print('The differenced time series is likely stationary.')
    # else:
    #     print('The differenced time series is likely non-stationary.')
    pass


def plot_acf_pacf(global_time_series, singapore_time_series):
    # Plot ACF
    # differenced_series = global_time_series.diff().dropna()
    # plot_acf(differenced_series['temperature_celsius'], lags=40)
    # plt.title('Autocorrelation Function (ACF) for Differenced Time Series')
    # plt.show()

    # # Plot PACF
    # differenced_series = global_time_series.diff().dropna()
    # plot_pacf(differenced_series['temperature_celsius'], lags=40)
    # plt.title('Partial Autocorrelation Function (PACF) for Differenced Time Series')
    # plt.show()
    pass


def fit_arima_model(global_time_series, singapore_time_series):
    # Fit ARIMA model for Global temperature
    global_model = ARIMA(global_time_series, order=(1, 1, 1))
    global_result = global_model.fit()

    # Fit ARIMA model for Singapore temperature
    singapore_model = ARIMA(singapore_time_series, order=(1, 0, 1))
    singapore_result = singapore_model.fit()
    return global_result, singapore_result


def forecast_future_temperatures(global_result, singapore_result):
    # Predict Future Temperature for Global (2024-2034)
    future_years = pd.date_range(start='2024-01-01', periods=10, freq='Y')
    global_forecast = global_result.get_forecast(steps=len(future_years))
    global_forecast_mean = global_forecast.predicted_mean

    # Predict Future Temperature for Singapore (2024-2034)
    singapore_forecast = singapore_result.get_forecast(steps=len(future_years))
    singapore_forecast_mean = singapore_forecast.predicted_mean
    return global_forecast_mean, singapore_forecast_mean, future_years


def plot_forecast(future_years, global_forecast_mean, singapore_forecast_mean):
    # Plotting predicted temperature trends for Global (2024-2034)
    plt.figure(figsize=(14, 6))
    plt.plot(future_years, global_forecast_mean, label='Global (Predicted)')
    plt.legend()
    plt.title('Predicted Temperature Trends for Global: 2024 to 2034')
    plt.xlabel('Year')
    plt.ylabel('Temperature (°C)')
    plt.show()

    # Plotting predicted temperature trends for Singapore (2024-2034)
    plt.figure(figsize=(14, 6))
    plt.plot(future_years, singapore_forecast_mean, label='Singapore (Predicted)', color='orange')
    plt.legend()
    plt.title('Predicted Temperature Trends for Singapore: 2024 to 2034')
    plt.xlabel('Year')
    plt.ylabel('Temperature (°C)')
    plt.show()
