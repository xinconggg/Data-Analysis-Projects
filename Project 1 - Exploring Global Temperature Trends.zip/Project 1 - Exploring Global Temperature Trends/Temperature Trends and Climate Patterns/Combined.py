# Import Required Libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf


# Read the Dataset
data = pd.read_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\GlobalWeatherRepository.csv")
# Display First 5 Rows
## print(data.head())
data['last_updated'] = pd.to_datetime(data['last_updated'], dayfirst=True)
data['last_updated'] = data['last_updated'].dt.date
# Summary Statistics
## print(data.describe())
# Check Data Type and Missing Values
## print(data.info())

# Check for NULL Values
##print(data.isnull().sum())
# Remove NULL Values
data = data.dropna()
# Check for NULL values again
##print(data.isnull().sum())

# Check for Misspellings or Inconsistencies
##print(data['country'].unique())
##print(data['location_name'].unique())

# Create a subset for Global Locations
global_subset = data[data['country'] != 'Singapore'].reset_index()
# Create a subset for Singapore
singapore_subset = data[data['country'] == 'Singapore'].reset_index()

# Save the cleaned datasets to a new CSV file
global_subset.to_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\GlobalSubset_Cleaned.csv", index=False)
singapore_subset.to_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\SingaporeSubset_Cleaned.csv", index=False)

# Remove country and location_name
global_subset = global_subset.drop(['country', 'location_name'], axis=1)
# Group by Date then Calculate Mean for each Variable
mean_global_subset = global_subset.groupby('last_updated').mean().reset_index()
# Save the Mean Dataset to a new CSV file
mean_global_subset.to_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\meanGlobalSubset.csv", index=False)


# # Correlation Heatmap
# # Combine both Global and Singapore data
# combined_data = pd.concat([mean_global_subset, singapore_subset], ignore_index=True)
# correlation_matrix_combined = combined_data[['temperature_celsius', 'wind_kph', 'pressure_mb', 'humidity', 'precip_mm']].corr()
# # Create a correlation heatmap
# plt.figure(figsize=(10, 8))
# sns.heatmap(correlation_matrix_combined, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5, square=True)
# plt.title('Correlation Heatmap: Combined Global and Singapore Data')
# plt.show()


# # Temperature Trend (Line Plot)
# plt.figure(figsize=(14, 6))
# # Temperature trend for Global
# sns.lineplot(x='last_updated', y='temperature_celsius', data=mean_global_subset, label='Global')
# # Temperature trend for Singapore
# sns.lineplot(x='last_updated', y='temperature_celsius', data=singapore_subset, label='Singapore')
# # Set plot title and labels
# plt.title('Temperature Trends Over Time: Global vs. Singapore')
# plt.xlabel('Date and Time')
# plt.ylabel('Temperature (°C)')
# # Set legend and display Line Plot
# plt.legend()
# plt.show()


# Time-Series Analysis (10 Years)
# Convert to datetime format
mean_global_subset['last_updated'] = pd.to_datetime(mean_global_subset['last_updated'], dayfirst=True)
singapore_subset['last_updated'] = pd.to_datetime(singapore_subset['last_updated'], dayfirst=True)

# Extract Year and Temperature for Time-Series
global_time_series = mean_global_subset[['last_updated', 'temperature_celsius']]
singapore_time_series = singapore_subset[['last_updated', 'temperature_celsius']]

# Set last_updated column as Index
global_time_series = global_time_series.set_index('last_updated')
singapore_time_series = singapore_time_series.set_index('last_updated')

# Create a new time index with daily frequency
global_time_index = pd.date_range(start=global_time_series.index.min(), end=global_time_series.index.max(), freq='D')
singapore_time_index = pd.date_range(start=singapore_time_series.index.min(), end=singapore_time_series.index.max(), freq='D')

# Reindex the time series with the new time index
global_time_series = global_time_series.reindex(global_time_index)
singapore_time_series = singapore_time_series.reindex(singapore_time_index)

# # Apply ADF test to figure out value of 'd'
# result = adfuller(global_time_series)
# # Extract the test statistic and p-value
# test_statistic = result[0]
# p_value = result[1]
# print(f'Test Statistic: {test_statistic}')
# print(f'P-value: {p_value}')
# # Check for stationarity
# if p_value <= 0.05:
#     print('The time series is likely stationary.')
# else:
#     print('The time series is likely non-stationary.')
# # Apply Differencing
# differenced_data = global_time_series.diff().dropna()
# # Perform ADF test on the differenced data
# result_diff = adfuller(differenced_data)
# test_statistic_diff = result_diff[0]
# p_value_diff = result_diff[1]
# print(f'Test Statistic (after differencing): {test_statistic_diff}')
# print(f'P-value (after differencing): {p_value_diff}')
# # Check for stationarity after differencing
# if p_value_diff <= 0.05:
#     print('The differenced time series is likely stationary.')
# else:
#     print('The differenced time series is likely non-stationary.')

# # Plot ACF
# differenced_series = global_time_series.diff().dropna()
# plot_acf(differenced_series['temperature_celsius'], lags=40)
# plt.title('Autocorrelation Function (ACF) for Differenced Time Series')
# plt.show()
#
# # Plot PACF
# differenced_series = global_time_series.diff().dropna()
# plot_pacf(differenced_series['temperature_celsius'], lags=40)
# plt.title('Partial Autocorrelation Function (PACF) for Differenced Time Series')
# plt.show()

# Fit ARIMA model for Global temperature
global_model = ARIMA(global_time_series, order=(1, 1, 1))
global_result = global_model.fit()

# Fit ARIMA model for Singapore temperature
singapore_model = ARIMA(singapore_time_series, order=(1, 0, 1))
singapore_result = singapore_model.fit()

# Predict Future Temperature for Global (2024-2034)
future_years = pd.date_range(start='2024-01-01', periods=10, freq='Y')
global_forecast = global_result.get_forecast(steps=len(future_years))
global_forecast_mean = global_forecast.predicted_mean

# Predict Future Temperature for Singapore (2024-2034)
singapore_forecast = singapore_result.get_forecast(steps=len(future_years))
singapore_forecast_mean = singapore_forecast.predicted_mean


# Plotting predicted temperature trends for Global (2024-2034)
plt.figure(figsize=(14, 6))
plt.plot(future_years, global_forecast_mean, label='Global (Predicted)')
plt.legend()
plt.title('Predicted Temperature Trends for Global: 2024 to 2034')
plt.xlabel('Year')
plt.ylabel('Temperature (°C)')
plt.show()

# Plotting predicted temperature trends for Singapore (2024-2034)
plt.figure(figsize=(14, 6))
plt.plot(future_years, singapore_forecast_mean, label='Singapore (Predicted)', color='orange')
plt.legend()
plt.title('Predicted Temperature Trends for Singapore: 2024 to 2034')
plt.xlabel('Year')
plt.ylabel('Temperature (°C)')
plt.show()