import pandas as pd
from data_processing import clean_data, create_subsets, save_cleaned_datasets
from temperature_analysis import plot_correlation_heatmap, plot_temperature_trends, time_series_analysis

# Read the Dataset
data = pd.read_csv("C:\\Users\\Xin Cong\\Downloads\\Data Analyst Project\\GlobalWeatherRepository.csv")

# Clean and process the data
cleaned_data = clean_data(data)
global_subset, singapore_subset = create_subsets(cleaned_data)
save_cleaned_datasets(global_subset, singapore_subset)

# Plot Correlation Heatmap
plot_correlation_heatmap(global_subset, singapore_subset)

# Plot Temperature Trends
plot_temperature_trends(global_subset, singapore_subset)

# Time-Series Analysis
time_series_analysis(global_subset, singapore_subset)
